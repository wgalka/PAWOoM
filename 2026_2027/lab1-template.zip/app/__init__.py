"""Student starter application."""

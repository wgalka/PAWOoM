"""Parcel Service application module."""

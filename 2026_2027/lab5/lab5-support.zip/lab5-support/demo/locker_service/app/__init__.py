"""Locker Service application module."""
